## **Hope Clinic in PHP**
==========================================================

### Technologies
- PHP >= 7.2
- MySQL Database
- Bootstrap
- AdminLTE
- FPDF

==========================================================
### **Developement Information**
==========================================================
#### ** Original Version**
- **Developed/Published By:** 	 Abid Elahi
- **Uploaded/Published at:** [https://www.kashipara.com/project/php/8527/patient-management-system-updated-](https://www.kashipara.com/project/php/8527/patient-management-system-updated-) 
==========================================================
#### ** Modified Version**
- **Modified By:** oretnom23
- **Published at:** [https://sourcecodester.com/php-clinics-patient-management-system-source-code](https://sourcecodester.com/php-clinics-patient-management-system-source-code) 

==========================================================
#### **Modification Information**
- Customize some of the User Interface (CSS)
- Modified Some features UI
- Fixed some errors encoundtered
==========================================================

==========================================================
#### **Admin Access**
- **Username:** admin
- **Password:** admin123
==========================================================
